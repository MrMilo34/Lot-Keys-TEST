LotKeys Facebook Posting Buddy Beta v0.1.20

Install / update
1. Unzip this package to a permanent folder.
2. Open chrome://extensions in Chrome.
3. Turn on Developer mode.
4. If updating, remove/reload the older LotKeys Facebook Assistant and choose Load unpacked for this folder.
5. Reload any open LotKeys and Facebook tabs once after installing the new version.

V0.1.20 simple update-page workflow
- Open Listing is now only a shortcut to the one Facebook URL currently saved in LotKeys. It does not verify the ad and it never starts editing automatically.
- Users may navigate to any Facebook Marketplace ad they want to update, including another ad for the same vehicle in a different area.
- The user opens Facebook's Edit listing page themselves, then presses Update Selected Items.
- Posting Buddy only checks that a Facebook Edit Listing form is actually open; it does not require that page to match the saved LotKeys URL.
- Video / Photos / Description / Details remain selective. Unchecked sections are left untouched.
- This intentionally keeps today's one-saved-URL design flexible for future multi-URL / multi-area listing tracking.

V0.1.19 verified two-step update workflow
- Existing Facebook Listings are no longer auto-opened and edited in one racing step.
- The green Update pill is now an Open Listing button. It only navigates to the saved Facebook Marketplace ad.
- The main action is state-aware: if the saved ad is not open it becomes Open Listing to Update; once verified it becomes Update Selected Items.
- Both workflows are supported: Open Listing first and inspect it, or choose update items first and press the main button twice (open, then update).
- Posting Buddy verifies the saved Marketplace item ID / canonical item URL before Edit Listing can run. A different Facebook ad stays locked even when it is the same vehicle.
- Harmless Facebook query/tracking changes do not break verification, while a different Marketplace item ID cannot be updated accidentally.
- No posting session is created during the navigation step, preventing the interrupted-session state seen when Facebook reloads.
- If Video is selected, its preparation can begin while the saved Listing is opening, preserving the speed-first workflow.

V0.1.18 speed-first posting + selective update workflow
- Moves connection/version/update status into a compact top strip.
- Adds one horizontal Post / Update row: Video, Photos, Description, Details.
- New Listings default to Photos + Description + Details; Video remains optional.
- Listings with a saved Facebook URL become selective Update jobs. Unchecked sections are left untouched.
- Video choice happens before the transfer. Posting Buddy discovers compatible Vehicle Profile and the signed-in user's More Media videos using Drive metadata without downloading them first.
- Only videos with ready duration metadata at 60 seconds or less can be selected.
- If Video is selected, its download/preparation starts while the chosen Facebook fields/photos are being filled, then the video is added last.
- A video problem never rolls back completed fields or photos.
- Photo updates prepare every LotKeys photo before removing existing Facebook photos; if Facebook does not expose safe replacement controls, the existing photos are left unchanged for manual review.
- The extension never clicks Facebook's final Next, Publish, Save, or Update action.
- After Save / Use this Website finishes a new post, Back returns directly to Listings and clears the completed posting session/timer.

Requires LotKeys V0.9.4.78 or newer for the lightweight Drive video-metadata bridge.
