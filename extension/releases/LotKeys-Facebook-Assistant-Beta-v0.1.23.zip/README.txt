LotKeys Facebook Posting Buddy - V0.1.23 Beta


V0.1.23
- Fresh video discovery no longer depends on editing/saving the LotKeys Listing. Selecting a Listing asks the open LotKeys tab to refresh the Vehicle Profile Videos folder directly from Drive and also rechecks that signed-in user's existing More Media video folder.
- When Video is selected, Posting Buddy begins preparing it as soon as a compatible choice is available. On the manual Post / Update click, the video is handed to Facebook first, then the selected Photos / Description / Details are filled while Facebook uploads/processes the video.
- Removes the old fixed post-video handoff delay. Posting Buddy watches the live Facebook editor instead and finishes the fields timer when the video is attached and Facebook enables the next Save / Update / Next step.
- Existing Listing photo replacement still loads the entire LotKeys photo set before deleting Facebook photos. Mixed Facebook media inputs preserve the selected video while photos are rebuilt in LotKeys order.
- Retains V0.1.22 replacement-style photo/text updates and V0.1.21 chunked large-video transfer.

V0.1.22
- Existing-listing Photos updates are now explicit replacements: Posting Buddy prepares the complete LotKeys photo set first, removes Facebook's existing photos one live tile at a time, then uploads the LotKeys selection in its saved order. It will not append duplicate photos to an existing Listing.
- If Facebook does not expose safe photo-removal controls, the live Facebook photos are left untouched and the photo step is flagged for manual review instead of risking duplicates.
- Existing-listing text updates now clear Model, Mileage, Price and Description before inserting the selected LotKeys values. Dropdown Details continue to be replaced by selecting the new value.
- Keeps V0.1.21 chunked large-video transfer, all four options selected by default on new posts, and selective unchecked-by-default controls for updates.

V0.1.21
- Fixes large walkaround video handoff: video bytes no longer travel as one base64 Chrome message. The selected Drive video is cached in the open LotKeys tab, transferred to Facebook in 4 MiB chunks, rebuilt as the original File, then handed to Facebook's Add video control. No local recompression or quality loss is introduced.
- The side panel never carries the full video payload; only small preparation metadata moves through it.
- Video preparation can still begin while Facebook photos/details are being filled, and Facebook receives the video last.
- New Facebook posts now start with Video + Photos + Description + Details selected by default. If no compatible <=60-second video exists, Video disables/unchecks automatically.
- Existing-listing updates still start with all sections unselected so the user can update only what changed.

Install / update
1. Unzip this package to a permanent folder.
2. Open chrome://extensions in Chrome.
3. Turn on Developer mode.
4. If updating, remove/reload the older LotKeys Facebook Assistant and choose Load unpacked for this folder.
5. Reload any open LotKeys and Facebook tabs once after installing the new version.

V0.1.20 simple update-page workflow
- Open Listing is now only a shortcut to the one Facebook URL currently saved in LotKeys. It does not verify the ad and it never starts editing automatically.
- Users may navigate to any Facebook Marketplace ad they want to update, including another ad for the same vehicle in a different area.
- The user opens Facebook's Edit listing page themselves, then presses Update Selected Items.
- Posting Buddy only checks that a Facebook Edit Listing form is actually open; it does not require that page to match the saved LotKeys URL.
- Video / Photos / Description / Details remain selective. Unchecked sections are left untouched.
- This intentionally keeps today's one-saved-URL design flexible for future multi-URL / multi-area listing tracking.

V0.1.19 verified two-step update workflow
- Existing Facebook Listings are no longer auto-opened and edited in one racing step.
- The green Update pill is now an Open Listing button. It only navigates to the saved Facebook Marketplace ad.
- The main action is state-aware: if the saved ad is not open it becomes Open Listing to Update; once verified it becomes Update Selected Items.
- Both workflows are supported: Open Listing first and inspect it, or choose update items first and press the main button twice (open, then update).
- Posting Buddy verifies the saved Marketplace item ID / canonical item URL before Edit Listing can run. A different Facebook ad stays locked even when it is the same vehicle.
- Harmless Facebook query/tracking changes do not break verification, while a different Marketplace item ID cannot be updated accidentally.
- No posting session is created during the navigation step, preventing the interrupted-session state seen when Facebook reloads.
- If Video is selected, its preparation can begin while the saved Listing is opening, preserving the speed-first workflow.

V0.1.18 speed-first posting + selective update workflow
- Moves connection/version/update status into a compact top strip.
- Adds one horizontal Post / Update row: Video, Photos, Description, Details.
- New Listings default to Video + Photos + Description + Details. Video automatically disables if no compatible <=60-second video is available.
- Listings with a saved Facebook URL become selective Update jobs. Unchecked sections are left untouched.
- Video choice happens before the transfer. Posting Buddy discovers compatible Vehicle Profile and the signed-in user's More Media videos using Drive metadata without downloading them first.
- Only videos with ready duration metadata at 60 seconds or less can be selected.
- If Video is selected, its download/preparation starts while the chosen Facebook fields/photos are being filled, then the video is added last.
- A video problem never rolls back completed fields or photos.
- Photo updates prepare every LotKeys photo before removing existing Facebook photos; if Facebook does not expose safe replacement controls, the existing photos are left unchanged for manual review.
- The extension never clicks Facebook's final Next, Publish, Save, or Update action.
- After Save / Use this Website finishes a new post, Back returns directly to Listings and clears the completed posting session/timer.

Requires LotKeys V0.9.4.78 or newer for the lightweight Drive video-metadata bridge.
