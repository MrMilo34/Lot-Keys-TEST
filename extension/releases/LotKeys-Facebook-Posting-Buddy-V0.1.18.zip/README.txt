LotKeys Facebook Posting Buddy Beta v0.1.18

Install / update
1. Unzip this package to a permanent folder.
2. Open chrome://extensions in Chrome.
3. Turn on Developer mode.
4. If updating, remove/reload the older LotKeys Facebook Assistant and choose Load unpacked for this folder.
5. Reload any open LotKeys and Facebook tabs once after installing the new version.

V0.1.18 speed-first posting + selective update workflow
- Moves connection/version/update status into a compact top strip.
- Adds one horizontal Post / Update row: Video, Photos, Description, Details.
- New Listings default to Photos + Description + Details; Video remains optional.
- Listings with a saved Facebook URL become selective Update jobs. Unchecked sections are left untouched.
- Video choice happens before the transfer. Posting Buddy discovers compatible Vehicle Profile and the signed-in user's More Media videos using Drive metadata without downloading them first.
- Only videos with ready duration metadata at 60 seconds or less can be selected.
- If Video is selected, its download/preparation starts while the chosen Facebook fields/photos are being filled, then the video is added last.
- A video problem never rolls back completed fields or photos.
- Photo updates prepare every LotKeys photo before removing existing Facebook photos; if Facebook does not expose safe replacement controls, the existing photos are left unchanged for manual review.
- The extension never clicks Facebook's final Next, Publish, Save, or Update action.
- After Save / Use this Website finishes a new post, Back returns directly to Listings and clears the completed posting session/timer.

Requires LotKeys V0.9.4.78 or newer for the lightweight Drive video-metadata bridge.
