const LOTKEYS_RE = /^https:\/\/(?:mrmilo34\.github\.io\/Lot-Keys(?:-TEST)?(?:\/|$)|(?:www\.)?lot-keys\.ca(?:\/|$))/i;
const FB_RE = /^https:\/\/(?:(?:www|m)\.)?facebook\.com\//i;
const HELPER_VERSION = '0.1.22';
const RUNTIME_VERSION_KEY = 'lotkeysHelperRuntimeVersion';

function configurePanel(){try{chrome.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true }).catch(() => {})}catch{}}

async function reloadOpenFacebookTabsOnceForVersion(){
  try{
    const stored = await chrome.storage.local.get(RUNTIME_VERSION_KEY);
    if(String(stored?.[RUNTIME_VERSION_KEY]||'')===HELPER_VERSION) return;
    await chrome.storage.local.set({[RUNTIME_VERSION_KEY]:HELPER_VERSION});
    const tabs = await chrome.tabs.query({});
    for(const tab of tabs){
      if(!tab?.id || !FB_RE.test(String(tab.url||''))) continue;
      try{ await chrome.tabs.reload(tab.id); }catch{}
    }
  }catch{}
}

chrome.runtime.onInstalled.addListener(() => { configurePanel(); reloadOpenFacebookTabsOnceForVersion(); });
chrome.runtime.onStartup.addListener(() => { configurePanel(); });
configurePanel();
// MV3 workers may restart independently of an extension update. The stored version guard makes this
// a one-time hard refresh only when a new Helper version is installed, never on ordinary worker wakeups.
reloadOpenFacebookTabsOnceForVersion();

async function allTabs() {
  return chrome.tabs.query({});
}
async function findLotKeysTab() {
  const tabs = await allTabs();
  return tabs.filter(t => LOTKEYS_RE.test(String(t.url || '')))
    .sort((a,b) => Number(b.lastAccessed||0)-Number(a.lastAccessed||0))[0] || null;
}
async function findFacebookTab() {
  const tabs = await allTabs();
  const active = tabs.find(t => t.active && FB_RE.test(String(t.url||'')));
  return active || tabs.filter(t => FB_RE.test(String(t.url||'')))
    .sort((a,b) => Number(b.lastAccessed||0)-Number(a.lastAccessed||0))[0] || null;
}

function marketplaceItemId(url){
  const match=String(url||'').match(/facebook\.com\/marketplace\/item\/([^/?#]+)/i);
  return match?decodeURIComponent(match[1]).toLowerCase():'';
}
function normalizedMarketplaceUrl(url){
  try{const parsed=new URL(String(url||''));const id=marketplaceItemId(parsed.href);return id?`https://facebook.com/marketplace/item/${id}`:''}catch{return ''}
}
async function facebookListingIdentity(tab){
  const base={url:String(tab?.url||''),canonicalUrl:'',title:String(tab?.title||'')};
  if(!tab?.id||!FB_RE.test(base.url))return base;
  try{
    await ensureFacebookScript(tab.id);
    const identity=await chrome.tabs.sendMessage(tab.id,{type:'LOTKEYS_LISTING_IDENTITY'});
    if(identity?.ok)return{url:String(identity.url||base.url),canonicalUrl:String(identity.canonicalUrl||''),title:String(identity.title||base.title)};
  }catch{}
  return base;
}
async function verifyFacebookListing(savedUrl,tab=null){
  const saved=String(savedUrl||'').trim(),savedId=marketplaceItemId(saved);tab=tab||await findFacebookTab();
  if(!tab)return{ok:true,facebook:false,verified:false,reason:'no-facebook-tab',savedItemId:savedId,currentItemId:'',currentUrl:'',canonicalUrl:''};
  const identity=await facebookListingIdentity(tab),currentUrls=[String(tab.url||''),identity.url,identity.canonicalUrl].filter(Boolean),currentIds=currentUrls.map(marketplaceItemId).filter(Boolean),currentId=currentIds[0]||'';
  const itemMatch=!!savedId&&currentIds.includes(savedId),savedCanonical=normalizedMarketplaceUrl(saved),canonicalMatch=!itemMatch&&!!savedCanonical&&currentUrls.some(url=>normalizedMarketplaceUrl(url)===savedCanonical);
  return{ok:true,facebook:true,verified:itemMatch||canonicalMatch,matchedBy:itemMatch?'item-id':canonicalMatch?'canonical-url':'',savedItemId:savedId,currentItemId:currentId,currentUrl:identity.url||String(tab.url||''),canonicalUrl:identity.canonicalUrl||'',title:identity.title||''};
}

async function executeLotKeysInTab(tabId, func, args=[]) {
  const result = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func,
    args
  });
  if (!result?.length) throw new Error('LotKeys did not return any data.');
  const value = result[0].result;
  if (value?.error) throw new Error(value.error);
  return value;
}
async function executeLotKeys(func, args=[]) {
  const tab = await findLotKeysTab();
  if (!tab) throw new Error('Open LotKeys in another Chrome tab first.');
  return executeLotKeysInTab(tab.id,func,args);
}

async function lotKeysAppearanceReader() {
  try {
    const body=document.body||document.documentElement,styles=getComputedStyle(body),read=(name,fallback)=>String(styles.getPropertyValue(name)||'').trim()||fallback;
    return {
      theme:String(document.body?.dataset?.theme||'light')==='dark'?'dark':'light',
      accent:read('--accent','#2563eb'),
      accentInk:read('--accent-ink','#ffffff'),
      background:read('--bg',String(styles.backgroundColor||'').trim()||'#f3f4f6'),
      card:read('--card','#ffffff'),
      ink:read('--ink','#111827'),
      muted:read('--muted','#6b7280'),
      line:read('--line','#e5e7eb'),
      updatedAt:Date.now()
    };
  } catch(err) {
    return {error:String(err?.message||err)};
  }
}

async function refreshLotKeysAppearance() {
  const appearance=await executeLotKeys(lotKeysAppearanceReader,[]);
  if(!appearance||appearance.error)throw new Error(appearance?.error||'Could not read LotKeys appearance.');
  await chrome.storage.local.set({lotkeysAppearance:appearance});
  return appearance;
}

async function lotKeysListingsReader() {
  const openStore = (name) => new Promise((resolve,reject) => {
    const req = indexedDB.open('autolister-v1');
    req.onerror = () => reject(req.error || new Error('Could not open LotKeys local database.'));
    req.onsuccess = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(name)) { db.close(); resolve([]); return; }
      const tx = db.transaction(name,'readonly');
      const get = tx.objectStore(name).getAll();
      get.onsuccess = () => { const rows=get.result||[]; db.close(); resolve(rows); };
      get.onerror = () => { db.close(); reject(get.error||new Error('Could not read '+name)); };
    };
  });
  try {
    let listings, vehicles, locations;
    if (typeof DB !== 'undefined' && DB?.all) {
      [listings, vehicles, locations] = await Promise.all([DB.all('listings'), DB.all('vehicles'), DB.all('locations')]);
    } else {
      [listings, vehicles, locations] = await Promise.all([openStore('listings'), openStore('vehicles'), openStore('locations')]);
    }
    const vehicleMap = new Map((vehicles||[]).map(v => [String(v.id||''),v]));
    const locationMap = new Map((locations||[]).map(x => [String(x.id||''),x]));
    const photoOrderFor = (l,v) => {
      const lp = Array.isArray(l?.listingAssets) ? l.listingAssets : [];
      const vp = Array.isArray(v?.photos) ? v.photos : [];
      const ids = [...vp,...lp].map(p=>String(p?.id||'')).filter(Boolean);
      const saved = Array.isArray(l?.photoOrder) ? l.photoOrder.map(x=>String(x||'')).filter(Boolean).slice(0,20) : [];
      // The Listing's saved selected IDs are authoritative. Do not discard a selected ID merely because
      // that Vehicle photo has not been hydrated into this browser tab yet.
      if (l?.photoOrderCustomized===true) return saved;
      if (saved.length) return saved;
      // Legacy Listings that predate explicit selection keep their historical all-photo fallback.
      return ids.slice(0,20);
    };
    return (listings||[])
      .filter(l => !['Sold','Archived'].includes(String(l?.status||'')))
      .map(l => {
        const v = vehicleMap.get(String(l.vehicleId||'')) || {};
        const loc = l.locationSnapshot || locationMap.get(String(l.locationId||'')) || {};
        const photoIds = photoOrderFor(l,v);
        const profileVideos = Array.isArray(v?.videos) ? v.videos : [];
        return {
          id: String(l.id||''),
          title: String(l.marketplaceTitle || [l.year||v.year,l.make||v.make,l.model||v.model].filter(Boolean).join(' ') || 'Untitled Listing'),
          year: String(l.year||v.year||''),
          make: String(l.make||v.make||''),
          model: String(l.model||v.model||''),
          bodyStyle: String(l.bodyStyle||v.bodyStyle||''),
          odometer: l.odometer!==''&&l.odometer!=null ? Number(l.odometer) : (v.odometer!==''&&v.odometer!=null ? Number(v.odometer) : ''),
          odometerUnit: String(l.odometerUnit||v.odometerUnit||'KM'),
          price: l.price!==''&&l.price!=null ? Number(l.price) : (v.price!==''&&v.price!=null ? Number(v.price) : ''),
          description: String(l.description||''),
          location: String(loc.postalCode||loc.name||loc.address||''),
          locationName: String(loc.name||''),
          locationPostalCode: String(loc.postalCode||''),
          locationAddress: String(loc.address||''),
          exteriorColor: String(l.exteriorColor||v.exteriorColor||''),
          interiorColor: String(l.interiorColor||v.interiorColor||''),
          vehicleCondition: String(l.vehicleCondition||v.vehicleCondition||''),
          fuelType: String(l.fuelType||v.fuelType||''),
          status: String(l.status||'Draft'),
          facebookUrl: String(l.facebookUrl||''),
          photoCount: Math.min(20,photoIds.length),
          photoIds: photoIds.slice(0,20),
          videoAvailable: profileVideos.length>0,
          videoCount: profileVideos.length,
          updatedAt: Number(l.updatedAt||0)
        };
      })
      .sort((a,b)=>b.updatedAt-a.updatedAt);
  } catch (err) {
    return {error: String(err?.message||err)};
  }
}

async function lotKeysPhotoReader(listingId, photoIndex, mode, requestedPhotoId) {
  const toDataURL = blob => new Promise((resolve,reject)=>{
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result||''));
    fr.onerror = () => reject(fr.error||new Error('Could not read photo.'));
    fr.readAsDataURL(blob);
  });
  const openDb = () => new Promise((resolve,reject)=>{
    const req=indexedDB.open('autolister-v1');
    req.onerror=()=>reject(req.error||new Error('Could not open LotKeys database.'));
    req.onsuccess=()=>resolve(req.result);
  });
  const getRow = async (store,id) => {
    const db=await openDb();
    try {
      if(!db.objectStoreNames.contains(store)) return null;
      return await new Promise((resolve,reject)=>{
        const req=db.transaction(store,'readonly').objectStore(store).get(id);
        req.onsuccess=()=>resolve(req.result||null); req.onerror=()=>reject(req.error);
      });
    } finally { db.close(); }
  };
  try {
    let l=null,v=null,photos=[];
    if (typeof DB !== 'undefined' && DB?.get) {
      l = await DB.get('listings', listingId);
      if (!l) throw new Error('Listing was not found in LotKeys.');
      v = l.vehicleId ? await DB.get('vehicles',l.vehicleId) : null;
      if (v && typeof DriveSync !== 'undefined' && DriveSync?.ready && await DriveSync.ready()) {
        try { v = await DriveSync.hydrateVehicleAssets(v); } catch(e) { console.warn('LotKeys Assistant photo hydrate',e); }
      }
      if (typeof hydrateListingAssets === 'function') {
        try { await hydrateListingAssets(l); } catch(e) { console.warn('LotKeys Assistant listing hydrate',e); }
      }
      if (typeof orderedListingPhotos === 'function') photos = orderedListingPhotos(l,v);
    }
    if (!l) {
      l=await getRow('listings',listingId);
      if(!l) throw new Error('Listing was not found in LotKeys.');
      v=l.vehicleId?await getRow('vehicles',l.vehicleId):null;
    }
    if (!photos.length) {
      const vp=Array.isArray(v?.photos)?v.photos:[],lp=Array.isArray(l?.listingAssets)?l.listingAssets:[];
      const all=[...vp,...lp],byId=new Map(all.map(p=>[String(p?.id||''),p]));
      const allIds=all.map(p=>String(p?.id||'')).filter(Boolean);
      let order=Array.isArray(l?.photoOrder)?l.photoOrder.map(String).filter(id=>byId.has(id)):allIds;
      order=order.slice(0,20);
      photos=order.map(id=>byId.get(id)).filter(Boolean);
    }
    const wantedId=String(requestedPhotoId||'');
    let p=null;
    if(wantedId){
      const allNow=[...(Array.isArray(v?.photos)?v.photos:[]),...(Array.isArray(l?.listingAssets)?l.listingAssets:[])];
      p=allNow.find(x=>String(x?.id||'')===wantedId)||photos.find(x=>String(x?.id||'')===wantedId)||null;
    }
    if(!p)p=photos[Number(photoIndex)||0];
    if(!p) throw new Error('Selected LotKeys photo '+(Number(photoIndex)+1)+' was not found.');
    let blob=p.blob||null;
    if(!blob && p.driveFileId && typeof DriveSync !== 'undefined' && DriveSync?.fetchFileBlob) {
      try { blob=await DriveSync.fetchFileBlob(p.driveFileId); } catch(e) { console.warn(e); }
    }
    if(!blob) throw new Error('Photo is not cached yet. Open the Listing Posting Assistant in LotKeys once, then retry.');
    if(String(mode||'')==='thumb'){
      try{
        const bmp=await createImageBitmap(blob),max=180,scale=Math.min(1,max/Math.max(bmp.width||1,bmp.height||1)),w=Math.max(1,Math.round((bmp.width||1)*scale)),h=Math.max(1,Math.round((bmp.height||1)*scale)),canvas=document.createElement('canvas');
        canvas.width=w;canvas.height=h;canvas.getContext('2d',{alpha:false}).drawImage(bmp,0,0,w,h);bmp.close?.();
        return {dataUrl:canvas.toDataURL('image/jpeg',0.78),name:String(p.name||`LotKeys-photo-${Number(photoIndex)+1}.jpg`),type:'image/jpeg',size:Number(blob.size||p.size||0),thumbnail:true};
      }catch(e){console.warn('LotKeys Assistant thumbnail fallback',e)}
    }
    return {dataUrl:await toDataURL(blob),name:String(p.name||`LotKeys-photo-${Number(photoIndex)+1}.jpg`),type:String(blob.type||p.type||'image/jpeg'),size:Number(blob.size||p.size||0)};
  } catch(err) { return {error:String(err?.message||err)}; }
}

async function lotKeysVideoCatalogReader(listingId) {
  const openDb=()=>new Promise((resolve,reject)=>{const req=indexedDB.open('autolister-v1');req.onerror=()=>reject(req.error||new Error('Could not open LotKeys database.'));req.onsuccess=()=>resolve(req.result)});
  const getRow=async(store,id)=>{if(typeof DB!=='undefined'&&DB?.get)return DB.get(store,id);const db=await openDb();try{if(!db.objectStoreNames.contains(store))return null;return await new Promise((resolve,reject)=>{const req=db.transaction(store,'readonly').objectStore(store).get(id);req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error)})}finally{db.close()}};
  const durationOf=item=>{const direct=Number(item?.durationSeconds||item?.duration)||0,driveMs=Number(item?.videoMediaMetadata?.durationMillis)||0;return direct>0?direct:(driveMs>0?driveMs/1000:0)};
  const sizeOf=item=>Number(item?.size)||Number(item?.blob?.size)||0;
  const out=[],indexById=new Map();
  const add=(item,source,label,pending=false)=>{
    const id=String(item?.driveFileId||item?.fileId||item?.id||'');if(!id)return;
    const mime=String(item?.mimeType||item?.type||'');if(mime&&!mime.startsWith('video/'))return;
    const duration=durationOf(item),eligible=duration>0&&duration<=60.05;
    const row={id,name:String(item?.name||'Vehicle video'),type:mime||'video/mp4',size:sizeOf(item),duration,eligible,source,sourceLabel:label,pending:!!pending,modifiedTime:String(item?.modifiedTime||'')};
    const existingIndex=indexById.get(id);
    if(existingIndex===undefined){indexById.set(id,out.length);out.push(row);return}
    const current=out[existingIndex];
    // Drive's videoMediaMetadata is usually richer than the cached Vehicle/Request row.
    // Merge duplicate IDs so an early cache entry cannot hide duration metadata returned by Drive.
    const preferIncomingDuration=row.duration>0&&!(current.duration>0);
    const preferIncomingSize=row.size>0&&!(current.size>0);
    const official=current.source==='official'||row.source==='official';
    const isPending=!!(current.pending||row.pending);
    out[existingIndex]={
      ...current,
      name:current.name&&current.name!=='Vehicle video'?current.name:row.name,
      type:current.type||row.type,
      size:preferIncomingSize?row.size:current.size,
      duration:preferIncomingDuration?row.duration:current.duration,
      eligible:(preferIncomingDuration?row.duration:current.duration)>0&&(preferIncomingDuration?row.duration:current.duration)<=60.05,
      source:official?'official':'more',
      sourceLabel:official?'Vehicle Profile':(isPending?'Your More Media · pending approval':(current.sourceLabel||row.sourceLabel||'Your More Media')),
      pending:official?false:isPending,
      modifiedTime:row.modifiedTime||current.modifiedTime
    };
  };
  try{
    const listing=await getRow('listings',String(listingId||''));if(!listing)throw new Error('Listing was not found in LotKeys.');let vehicle=listing.vehicleId?await getRow('vehicles',listing.vehicleId):null;if(!vehicle)throw new Error('The Vehicle Profile for this Listing could not be found.');
    for(const item of (Array.isArray(vehicle.videos)?vehicle.videos:[]))add(item,'official','Vehicle Profile');
    let driveReady=false;if(typeof DriveSync!=='undefined'&&DriveSync?.ready){try{driveReady=!!(await DriveSync.ready())}catch{driveReady=false}}
    if(driveReady&&vehicle.drive?.videosFolderId&&DriveSync?.listVideoMetadata){
      try{for(const item of await DriveSync.listVideoMetadata(vehicle.drive.videosFolderId))add(item,'official','Vehicle Profile')}catch(error){console.warn('Posting Buddy official video catalog',error)}
    }
    let viewer={};try{if(typeof currentUserRecord==='function')viewer=await currentUserRecord()}catch{};
    const viewerSub=String(viewer?.googleSub||''),viewerEmail=String(viewer?.email||'').trim().toLowerCase(),viewerName=String(viewer?.userName||'');
    const mine=req=>{const rs=String(req?.userGoogleSub||''),re=String(req?.userEmail||'').trim().toLowerCase(),rn=String(req?.userName||'');return !!((viewerSub&&rs&&viewerSub===rs)||(viewerEmail&&re&&viewerEmail===re)||(!rs&&!re&&viewerName&&rn&&viewerName.toLowerCase()===rn.toLowerCase()))};
    for(const req of (Array.isArray(vehicle.contributionRequests)?vehicle.contributionRequests:[]))if(mine(req))for(const item of (Array.isArray(req?.media?.videos)?req.media.videos:[]))if(String(item?.status||'pending')!=='official')add(item,'more','Your More Media · pending approval',true);
    let workspace=null;
    if(driveReady&&DriveSync?.openExistingMoreMedia){
      try{const found=await DriveSync.openExistingMoreMedia(vehicle,{force:true});workspace=found?.workspace||null}catch(error){console.warn('Posting Buddy More Media catalog',error)}
    }
    if(!workspace&&vehicle.moreWorkspace&&typeof vehicle.moreWorkspace==='object')workspace=vehicle.moreWorkspace;
    const moreVideoFolderId=String(workspace?.videosFolderId||'');
    if(driveReady&&moreVideoFolderId&&DriveSync?.listVideoMetadata){
      try{for(const item of await DriveSync.listVideoMetadata(moreVideoFolderId))add(item,'more','Your More Media',true)}catch(error){console.warn('Posting Buddy More video catalog',error)}
    }
    out.sort((a,b)=>(Number(b.eligible)-Number(a.eligible))||((a.source==='official'?0:1)-(b.source==='official'?0:1))||(Number(b.modifiedTime?Date.parse(b.modifiedTime):0)-Number(a.modifiedTime?Date.parse(a.modifiedTime):0)));
    return {videos:out,compatibleCount:out.filter(x=>x.eligible).length,officialCount:out.filter(x=>x.source==='official').length,moreCount:out.filter(x=>x.source==='more').length};
  }catch(error){return {error:String(error?.message||error),videos:[]}}
}

async function lotKeysVideoPrepareReader(listingId, requestedVideoId) {
  const openDb=()=>new Promise((resolve,reject)=>{const req=indexedDB.open('autolister-v1');req.onerror=()=>reject(req.error||new Error('Could not open LotKeys database.'));req.onsuccess=()=>resolve(req.result)});
  const getRow=async(store,id)=>{if(typeof DB!=='undefined'&&DB?.get)return DB.get(store,id);const db=await openDb();try{if(!db.objectStoreNames.contains(store))return null;return await new Promise((resolve,reject)=>{const req=db.transaction(store,'readonly').objectStore(store).get(id);req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error)})}finally{db.close()}};
  try{
    const listing=await getRow('listings',String(listingId||''));if(!listing)throw new Error('Listing was not found in LotKeys.');const vehicle=listing.vehicleId?await getRow('vehicles',listing.vehicleId):null;if(!vehicle)throw new Error('The Vehicle Profile for this Listing could not be found.');const videoId=String(requestedVideoId||'');if(!videoId)throw new Error('Choose a video first.');
    const allowedFolders=new Set();if(vehicle.drive?.videosFolderId)allowedFolders.add(String(vehicle.drive.videosFolderId));
    let viewer={};try{if(typeof currentUserRecord==='function')viewer=await currentUserRecord()}catch{};const viewerSub=String(viewer?.googleSub||''),viewerEmail=String(viewer?.email||'').trim().toLowerCase(),viewerName=String(viewer?.userName||'');
    const mine=req=>{const rs=String(req?.userGoogleSub||''),re=String(req?.userEmail||'').trim().toLowerCase(),rn=String(req?.userName||'');return !!((viewerSub&&rs&&viewerSub===rs)||(viewerEmail&&re&&viewerEmail===re)||(!rs&&!re&&viewerName&&rn&&viewerName.toLowerCase()===rn.toLowerCase()))};
    const pendingIds=new Set();for(const req of (Array.isArray(vehicle.contributionRequests)?vehicle.contributionRequests:[]))if(mine(req))for(const item of (Array.isArray(req?.media?.videos)?req.media.videos:[])){const id=String(item?.driveFileId||item?.fileId||item?.id||'');if(id)pendingIds.add(id)}
    let driveReady=false;if(typeof DriveSync!=='undefined'&&DriveSync?.ready){try{driveReady=!!(await DriveSync.ready())}catch{driveReady=false}}if(driveReady&&DriveSync?.openExistingMoreMedia){try{const found=await DriveSync.openExistingMoreMedia(vehicle,{force:true});if(found?.workspace?.videosFolderId)allowedFolders.add(String(found.workspace.videosFolderId))}catch(error){console.warn('Posting Buddy More validation',error)}}else if(vehicle.moreWorkspace?.videosFolderId)allowedFolders.add(String(vehicle.moreWorkspace.videosFolderId));
    let meta=null;if(driveReady&&DriveSync?.getVideoMetadata)meta=await DriveSync.getVideoMetadata(videoId).catch(()=>null);
    const parents=(meta?.parents||[]).map(String),allowed=pendingIds.has(videoId)||parents.some(id=>allowedFolders.has(id))||(Array.isArray(vehicle.videos)&&vehicle.videos.some(x=>String(x?.driveFileId||x?.id||'')===videoId));if(!allowed)throw new Error('That video is not part of this Vehicle Profile or your More Media folder.');
    const local=[...(Array.isArray(vehicle.videos)?vehicle.videos:[])];for(const req of (Array.isArray(vehicle.contributionRequests)?vehicle.contributionRequests:[]))if(mine(req))local.push(...(Array.isArray(req?.media?.videos)?req.media.videos:[]));const localItem=local.find(x=>String(x?.driveFileId||x?.fileId||x?.id||'')===videoId)||{};
    const duration=(Number(meta?.videoMediaMetadata?.durationMillis)||0)/1000||Number(localItem?.durationSeconds||localItem?.duration)||0;if(!Number.isFinite(duration)||duration<=0)throw new Error('Google Drive is still processing this video’s duration. Try again shortly.');if(duration>60.05)throw new Error('The selected video is over Facebook’s 60-second limit.');
    let blob=localItem?.blob||null;if(!blob&&typeof DriveSync!=='undefined'&&DriveSync?.fetchFileBlob)blob=await DriveSync.fetchFileBlob(videoId);if(!blob&&typeof fetchFileBlob==='function')blob=await fetchFileBlob(videoId);if(!blob)throw new Error('The selected video could not be downloaded.');
    const cache=globalThis.__LOTKEYS_POSTING_BUDDY_VIDEO_CACHE instanceof Map?globalThis.__LOTKEYS_POSTING_BUDDY_VIDEO_CACHE:(globalThis.__LOTKEYS_POSTING_BUDDY_VIDEO_CACHE=new Map()),now=Date.now();
    for(const [key,row] of cache.entries())if(!row||now-Number(row.createdAt||0)>15*60*1000)cache.delete(key);
    const token=(globalThis.crypto?.randomUUID?.()||('lkvideo-'+now.toString(36)+'-'+Math.random().toString(36).slice(2))),name=String(meta?.name||localItem?.name||'LotKeys-walkaround.mp4'),type=String(blob.type||meta?.mimeType||localItem?.type||'video/mp4'),size=Number(blob.size||meta?.size||localItem?.size||0);
    cache.set(token,{blob,createdAt:now,id:videoId,name,type,size,duration});
    return {token,id:videoId,name,type,size,duration,chunkSize:4*1024*1024};
  }catch(error){return {error:String(error?.message||error)}}
}

async function lotKeysVideoChunkReader(token, offset, length) {
  try{
    const cache=globalThis.__LOTKEYS_POSTING_BUDDY_VIDEO_CACHE;if(!(cache instanceof Map))throw new Error('Prepared video expired. Select the video again.');const entry=cache.get(String(token||''));if(!entry?.blob)throw new Error('Prepared video expired. Select the video again.');
    if(Date.now()-Number(entry.createdAt||0)>15*60*1000){cache.delete(String(token||''));throw new Error('Prepared video expired. Select the video again.')}
    const total=Number(entry.blob.size||entry.size||0),start=Math.max(0,Math.min(total,Number(offset)||0)),wanted=Math.max(1,Math.min(4*1024*1024,Number(length)||4*1024*1024)),end=Math.min(total,start+wanted),bytes=new Uint8Array(await entry.blob.slice(start,end).arrayBuffer());
    let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+0x8000,bytes.length)));
    return {token:String(token||''),offset:start,end,byteLength:bytes.length,total,base64:btoa(binary),done:end>=total};
  }catch(error){return {error:String(error?.message||error)}}
}

function lotKeysVideoReleaseReader(token) {
  try{const cache=globalThis.__LOTKEYS_POSTING_BUDDY_VIDEO_CACHE;if(cache instanceof Map)cache.delete(String(token||''));return {ok:true}}catch(error){return {error:String(error?.message||error)}}
}



async function lotKeysListingWriteback(listingId, facebookUrl, views) {
  const openDb = () => new Promise((resolve,reject)=>{const req=indexedDB.open('autolister-v1');req.onerror=()=>reject(req.error||new Error('Could not open LotKeys database.'));req.onsuccess=()=>resolve(req.result)});
  const getRow=async(store,id)=>{if(typeof DB!=='undefined'&&DB?.get)return DB.get(store,id);const db=await openDb();try{return await new Promise((resolve,reject)=>{const req=db.transaction(store,'readonly').objectStore(store).get(id);req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error)})}finally{db.close()}};
  const putRow=async(store,row)=>{if(typeof DB!=='undefined'&&DB?.put)return DB.put(store,row);const db=await openDb();try{return await new Promise((resolve,reject)=>{const req=db.transaction(store,'readwrite').objectStore(store).put(row);req.onsuccess=()=>resolve(row);req.onerror=()=>reject(req.error)})}finally{db.close()}};
  const l=await getRow('listings',String(listingId||''));if(!l)throw new Error('Selected LotKeys Listing was not found.');
  let urlSaved=false,viewsSaved=false;const url=String(facebookUrl||'').trim();
  if(url){if(!/^https:\/\/(?:(?:www|m)\.)?facebook\.com\/marketplace\/item\/[^/?#]+/i.test(url))throw new Error('Open this vehicle’s live Facebook Marketplace item page first.');l.facebookUrl=url;l.status='Active';l.postedAt=l.postedAt||Date.now();l.updatedAt=Date.now();l.syncStatus='pending';await putRow('listings',l);urlSaved=true;try{if(typeof DriveSync!=='undefined'&&DriveSync?.ready&&await DriveSync.ready()&&DriveSync?.syncListing)await DriveSync.syncListing(l)}catch(e){console.warn('LotKeys Assistant listing sync',e)}}
  if(views!==''&&views!=null){const n=Number(String(views).replace(/[^0-9.-]/g,''));if(!Number.isFinite(n)||n<0)throw new Error('Enter a valid view count.');const d=new Date(),date=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;await putRow('analytics',{id:`AN-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`,listingId:String(listingId||''),date,views:Math.round(n)});viewsSaved=true}
  return {ok:true,urlSaved,viewsSaved,facebookUrl:l.facebookUrl||'',views:viewsSaved?Math.round(Number(views)):null};
}

async function ensureFacebookScript(tabId) {
  try { const pong=await chrome.tabs.sendMessage(tabId,{type:'LOTKEYS_PING'}); if(pong?.ok&&pong?.version===HELPER_VERSION)return; }
  catch {}
  await chrome.scripting.executeScript({target:{tabId},files:['facebook.js']});
  await new Promise(r=>setTimeout(r,150));
}

async function waitForTabComplete(tabId,timeout=9000){
  try{const current=await chrome.tabs.get(tabId);if(current?.status==='complete')return current}catch{}
  return new Promise(resolve=>{let done=false;const finish=async()=>{if(done)return;done=true;clearTimeout(timer);chrome.tabs.onUpdated.removeListener(onUpdated);try{resolve(await chrome.tabs.get(tabId))}catch{resolve(null)}};const onUpdated=(id,info)=>{if(id===tabId&&info.status==='complete')finish()};const timer=setTimeout(finish,timeout);chrome.tabs.onUpdated.addListener(onUpdated)});
}


async function releasePreparedVideo(preparation={}){
  const token=String(preparation?.token||''),tabId=Number(preparation?.lotKeysTabId)||0;if(!token||!tabId)return;
  try{await executeLotKeysInTab(tabId,lotKeysVideoReleaseReader,[token])}catch{}
}
async function transferPreparedVideoToFacebook(preparation={}){
  const token=String(preparation?.token||''),lotKeysTabId=Number(preparation?.lotKeysTabId)||0,total=Number(preparation?.size)||0,chunkSize=Math.max(256*1024,Math.min(4*1024*1024,Number(preparation?.chunkSize)||4*1024*1024));
  if(!token||!lotKeysTabId||!total)throw new Error('The selected video is not prepared yet. Select it again.');
  const lotKeysTab=await chrome.tabs.get(lotKeysTabId).catch(()=>null);if(!lotKeysTab||!LOTKEYS_RE.test(String(lotKeysTab.url||'')))throw new Error('The LotKeys tab that prepared this video is no longer available. Select the video again.');
  const tab=await findFacebookTab();if(!tab)throw new Error('Open Facebook Marketplace first.');await ensureFacebookScript(tab.id);
  const transfer={token,name:String(preparation?.name||'LotKeys-walkaround.mp4'),type:String(preparation?.type||'video/mp4'),size:total,duration:Number(preparation?.duration)||0};
  let begun=false;
  try{
    const begin=await chrome.tabs.sendMessage(tab.id,{type:'LOTKEYS_VIDEO_TRANSFER_BEGIN',transfer});if(!begin?.ok)throw new Error(begin?.error||'Facebook could not prepare for the video transfer.');begun=true;
    for(let offset=0,index=0;offset<total;index++){
      const chunk=await executeLotKeysInTab(lotKeysTabId,lotKeysVideoChunkReader,[token,offset,chunkSize]);if(!chunk||chunk.error)throw new Error(chunk?.error||'Could not read the next video chunk.');
      const ack=await chrome.tabs.sendMessage(tab.id,{type:'LOTKEYS_VIDEO_TRANSFER_CHUNK',token,index,offset:chunk.offset,byteLength:chunk.byteLength,base64:chunk.base64});if(!ack?.ok)throw new Error(ack?.error||'Facebook could not receive the next video chunk.');
      offset=Number(chunk.end)||offset+Number(chunk.byteLength||0);if(!(offset>0))throw new Error('Video transfer did not advance.');
    }
    const result=await chrome.tabs.sendMessage(tab.id,{type:'LOTKEYS_VIDEO_TRANSFER_COMMIT',token});if(!result?.ok)throw new Error(result?.error||'Facebook could not add the selected video.');return result;
  }catch(error){if(begun)try{await chrome.tabs.sendMessage(tab.id,{type:'LOTKEYS_VIDEO_TRANSFER_ABORT',token})}catch{};throw error}
  finally{await releasePreparedVideo(preparation)}
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async()=>{
    if(msg?.type==='GET_TAB_STATUS') {
      const [lotkeys,facebook]=await Promise.all([findLotKeysTab(),findFacebookTab()]);
      return {ok:true,lotkeys:!!lotkeys,facebook:!!facebook,lotkeysTitle:lotkeys?.title||'',facebookTitle:facebook?.title||''};
    }
    if(msg?.type==='SYNC_LISTINGS') {
      const rows=await executeLotKeys(lotKeysListingsReader,[]);
      if(!Array.isArray(rows)) throw new Error(rows?.error||'Could not read LotKeys Listings.');
      let appearance=null;try{appearance=await refreshLotKeysAppearance()}catch{}
      await chrome.storage.local.set({lotkeysListings:rows,lotkeysListingsSyncedAt:Date.now()});
      return {ok:true,listings:rows,appearance};
    }
    if(msg?.type==='GET_LOTKEYS_APPEARANCE') {
      const appearance=await refreshLotKeysAppearance();
      return {ok:true,appearance};
    }
    if(msg?.type==='GET_PHOTO') {
      const photo=await executeLotKeys(lotKeysPhotoReader,[String(msg.listingId||''),Number(msg.photoIndex||0),'full',String(msg.photoId||'')]);
      return {ok:true,photo};
    }
    if(msg?.type==='GET_THUMB') {
      const photo=await executeLotKeys(lotKeysPhotoReader,[String(msg.listingId||''),Number(msg.photoIndex||0),'thumb',String(msg.photoId||'')]);
      return {ok:true,photo};
    }
    if(msg?.type==='GET_VIDEO_CATALOG') {
      const catalog=await executeLotKeys(lotKeysVideoCatalogReader,[String(msg.listingId||'')]);if(catalog?.error)throw new Error(catalog.error);return {ok:true,...catalog};
    }
    if(msg?.type==='PREPARE_VIDEO') {
      const lotKeysTab=await findLotKeysTab();if(!lotKeysTab)throw new Error('Open LotKeys in another Chrome tab first.');const preparation=await executeLotKeysInTab(lotKeysTab.id,lotKeysVideoPrepareReader,[String(msg.listingId||''),String(msg.videoId||'')]);if(!preparation||preparation.error)throw new Error(preparation?.error||'Could not prepare the selected video from LotKeys.');return {ok:true,preparation:{...preparation,lotKeysTabId:lotKeysTab.id}};
    }
    if(msg?.type==='TRANSFER_PREPARED_VIDEO') {
      return await transferPreparedVideoToFacebook(msg.preparation||{});
    }
    if(msg?.type==='RELEASE_PREPARED_VIDEO') {
      await releasePreparedVideo(msg.preparation||{});return {ok:true};
    }
    if(msg?.type==='VERIFY_FACEBOOK_LISTING') {
      const url=String(msg.facebookUrl||'').trim();if(!/^https:\/\/(?:(?:www|m)\.)?facebook\.com\/marketplace\/item\/[^/?#]+/i.test(url))return{ok:true,facebook:!!(await findFacebookTab()),verified:false,reason:'invalid-saved-url'};return await verifyFacebookListing(url);
    }
    if(msg?.type==='OPEN_FACEBOOK_LISTING') {
      const url=String(msg.facebookUrl||'').trim();if(!/^https:\/\/(?:(?:www|m)\.)?facebook\.com\/marketplace\/item\/[^/?#]+/i.test(url))throw new Error('This Listing does not have a valid saved Facebook URL yet.');const tab=await findFacebookTab();if(!tab)throw new Error('Open Facebook in Chrome first.');await chrome.tabs.update(tab.id,{url});return{ok:true,opened:true};
    }
    if(msg?.type==='CHECK_FACEBOOK_EDIT_READY') {
      const tab=await findFacebookTab();if(!tab)return{ok:false,ready:false,error:'Open Facebook in Chrome first.'};await ensureFacebookScript(tab.id);try{const state=await chrome.tabs.sendMessage(tab.id,{type:'LOTKEYS_EDIT_READY'});return state||{ok:true,ready:false}}catch{return{ok:false,ready:false,error:'Open the Facebook Listing you want to update, choose Edit listing, then press Update Selected Items.'}}
    }
    if(msg?.type==='GET_FACEBOOK_URL') {
      const tab=await findFacebookTab();
      return {ok:!!tab,url:String(tab?.url||''),title:String(tab?.title||'')};
    }
    if(msg?.type==='SAVE_LISTING_FOLLOWUP') {
      const out=await executeLotKeys(lotKeysListingWriteback,[String(msg.listingId||''),String(msg.facebookUrl||''),msg.views??'']);
      return out||{ok:false,error:'LotKeys did not save the update.'};
    }
    if(msg?.type==='JUMP_FIELD') {
      const tab=await findFacebookTab();if(!tab)throw new Error('Open Facebook Marketplace first.');await ensureFacebookScript(tab.id);
      return await chrome.tabs.sendMessage(tab.id,{type:'LOTKEYS_JUMP_TO_FIELD',key:String(msg.key||'')});
    }
    if(msg?.type==='RETRY_FIELD') {
      const tab=await findFacebookTab();if(!tab)throw new Error('Open Facebook Marketplace first.');await ensureFacebookScript(tab.id);
      return await chrome.tabs.sendMessage(tab.id,{type:'LOTKEYS_RETRY_FIELD',key:String(msg.key||''),listing:msg.listing||{}});
    }
    if(msg?.type==='CHECK_FACEBOOK_FIELDS') {
      const tab=await findFacebookTab();if(!tab)throw new Error('Open Facebook Marketplace first.');await ensureFacebookScript(tab.id);
      return await chrome.tabs.sendMessage(tab.id,{type:'LOTKEYS_CHECK_FIELDS',keys:Array.isArray(msg.keys)?msg.keys:[]});
    }
    if(msg?.type==='FILL_FACEBOOK') {
      const tab=await findFacebookTab();
      if(!tab) throw new Error('Open Facebook Marketplace → Vehicle for sale in Chrome first.');
      await ensureFacebookScript(tab.id);
      const result=await chrome.tabs.sendMessage(tab.id,{type:'LOTKEYS_FILL_FACEBOOK',listing:msg.listing});
      return result||{ok:false,error:'Facebook did not return a result.'};
    }
    return null;
  })().then(r=>sendResponse(r)).catch(err=>sendResponse({ok:false,error:String(err?.message||err)}));
  return true;
});
